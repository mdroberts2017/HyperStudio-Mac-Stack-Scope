/* Branch scope policy. Michael Roberts, 2026. MIT. */
window.HSBranch=(()=>{'use strict';
const accepts=family=>HSProduct.id==='mac'?!['iigs','iigs-header-candidate','iigs-container'].includes(family):!['hs5','legacy-mac','macpaint','mac-picture'].includes(family);
const familyFor=r=>r.hs5Model?'hs5':r.model?.schema==='hyperstudio-iigs-structure'?'iigs':r.model?.schema==='hyperstudio-legacy-big-endian-structure'?'legacy-mac':r.family;
const reason=family=>accepts(family)?'':HSProduct.id==='mac'?'Apple IIGS content belongs in HyperStudio IIGS Stack Scope.':'Macintosh stacks and picture assets belong in HyperStudio Mac Stack Scope.';
return {accepts,acceptsRecord:r=>accepts(familyFor(r)),familyFor,reason};})();
