"""Create a reproducible, original 3-card inspection demo in the observed HS5 schema.
This generated fixture is not certified as a native HyperStudio-authorable project.
Michael Roberts, 2026. MIT.
"""
from pathlib import Path
import plistlib,zipfile,io,json,uuid
p=Path(__file__).resolve().parent
uid=lambda name:{'EXClassName':'_HSCFUUID','stringValue':str(uuid.uuid5(uuid.NAMESPACE_URL,'scope-mac-demo/'+name)).upper()}
entries={}
def doc(path,d):entries[path]=plistlib.dumps(d,sort_keys=False)
def color(r,g,b,a=1):return {'EXClassName':'NSColor','redComponent':r,'greenComponent':g,'blueComponent':b,'alphaComponent':a}
def run(text,size=16,bold=False,ink=None):return {'string':text,'attributes':{'NSFont':{'EXClassName':'NSFont','familyName':'Arial','fontName':'Arial-Bold' if bold else 'Arial','pointSize':size},'NSColor':ink or color(.12,.18,.28),'NSParagraphStyle':{'alignment':0,'lineSpacing':2}}}
def obj(card,name,kind,x,y,w,h,extra=None,unit=None):
 d={'EXClassName':kind,'hyperOrderWeight':str(1000+len(entries)),'localNodeData':{'UID':uid(name),'name':name,'hidden':False},'units':{'size':{'EXClassName':'HSSizeNodeUnit','sizeAsString':'{%d, %d}'%(w,h)},'geometry':{'EXClassName':'HSGeometryNodeUnit','affineTransformAsArray':[1,0,0,1,x,y]}}}
 if unit:d['units']['image']=unit
 if extra:d.update(extra)
 doc('Contents/Stack.hsstack/Card_%d.hscard/%s.hsobject'%(card,name),d)
def text(card,name,x,y,w,h,runs):obj(card,name,'HSSystemTextView',x,y,w,h,{'hyperText':{'EXClassName':'NSAttributedString','attributedString':runs}})
doc('Version.plist',{'CompatibilityVersionNumber':'5.0'})
doc('Contents.plist',{'HSDocumentCompatibilityVersion':'1026','HSDocumentCreatorVersion':'0','HSDocumentVersion':'1342','ScopeSampleProvenance':'Generated inspection demo; no native creator release inferred'})
doc('Contents/Stack.hsstack/Stack.hsstack',{'EXClassName':'HSStack','cardSizeAsString':'{640, 400}','localNodeData':{'UID':uid('stack'),'name':'Mac Inspection Demo'}})
for i,title in enumerate(['Mac Sample Home','Formatted Fields','Macintosh Picture Assets'],1):
 doc('Contents/Stack.hsstack/Card_%d.hscard/Card_%d.hscard'%(i,i),{'EXClassName':'HSCard','hyperOrderWeight':str(i*100),'localNodeData':{'UID':uid('card'+str(i)),'name':title,'title':title},'backgroundGraphics':{'isSolid':True,'startColor-EXMultiRepresentations':color(.94,.96,.99)}})
 text(i,'Heading'+str(i),34,28,572,56,[run(title,28,True,color(.12,.29,.51))])
text(1,'Welcome',34,104,572,160,[run('HyperStudio Mac Stack Scope\n',22,True),run('Explore Macintosh stack structures, recovered text, pictures and saved actions.\n\nUse Next to inspect formatted fields and picture layers.',18)])
version=json.loads((p/'products.json').read_text())['mac'];versionLabel=version['version']+' Dev'+str(version['dev'])
text(1,'Footer',34,304,572,64,[run('Mac branch · '+versionLabel+'\nIncluded inspection demo',14,False,color(.3,.4,.55))])
text(2,'StyledField',34,108,572,112,[run('Saved text runs\n',22,True),run('This line uses blue ink. ',17,False,color(.12,.31,.65)),run('This run uses bold type.\n',17,True),run('Field bounds clip the display while the recovered text view retains the complete content.',16)])
text(2,'LongField',34,254,572,82,[run('Scrollable text example\n',18,True),run(('Recovered text remains available even when the visible field is too short. '*18),16)])
for dpath,db in list(entries.items()):
 if dpath.endswith('StyledField.hsobject'):
  d=plistlib.loads(db)
  for r in d['hyperText']['attributedString']:
   r['attributes']['NSParagraphStyle'].update(firstLineHeadIndent=12,headIndent=6,tailIndent=-12,tabStops=[{'location':150,'tabStopType':0}])
  d['hyperText']['attributedString'][1]['string']='Blue ink.\t'
  entries[dpath]=plistlib.dumps(d,sort_keys=False)
for label,file,x in [('PICT','sample.pict',52),('TIFF','sample.tiff',356)]:
 source=p/'sample-assets'/file;entries['Contents/Resources/'+file]=source.read_bytes()
 doc('Contents/Resources/'+label+'.plist',{'EXClassName':'HSMediaWrapper','uid':uid(label),'mediaName':file,'mediaPath':file,'mediaType':'image/'+label.lower()})
 obj(3,label+'Image','HSImageObject',x,116,232,155,unit={'EXClassName':'HSEditableImageNodeUnit','mediaUID':uid(label)})
 text(3,label+'Caption',x,282,232,68,[run(label+' picture\n',19,True),run('Original bytes + PNG export',13)])
b=io.BytesIO()
with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in entries.items():
  info=zipfile.ZipInfo(name,(2026,10,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
data=bytearray(b.getvalue());data[:2]=b'HS';(p/'Mac_Inspection_Demo.hsa').write_bytes(data)
(p/'Mac_Sample_Provenance.json').write_text(json.dumps({'sampleKind':'generated-inspection-demo','cards':3,'author':'Michael Roberts','sourceApplication':None,'nativeApplicationValidation':False,'description':'Original fixture in the observed HS5 serialization; source package is preserved as supplied.'},indent=2))
print('Mac sample',len(data),'bytes')
