"""Original behavior evidence fixture; not native-authored. Michael Roberts, MIT."""
from pathlib import Path
import zipfile,plistlib,io,json
p=Path(__file__).resolve().parents[1];b=(p/'Examples/Shared_State_Inspection.hsa').read_bytes();z=zipfile.ZipFile(io.BytesIO(b'PK'+b[2:]));entries={n:z.read(n) for n in z.namelist() if not n.endswith('/')};docs={n:plistlib.loads(v) for n,v in entries.items() if n.endswith(('.hsstack','.hscard','.hsobject','.plist'))}
def uid(s):return {'EXClassName':'_HSCFUUID','stringValue':s}
def url(s):return {'EXClassName':'NSURL','absoluteString':s}
stack=next(d for d in docs.values() if d.get('EXClassName')=='HSStack');group=stack['cardGroups-EXConformedCollection'][0]['groupData-EXConformedCollection'][0]
children=[{'EXClassName':'HSOtherCardAction','destinationCardUID':uid('CARD-2')},{'EXClassName':'HSGoToURLAction','currentAction':{'EXClassName':'HSOpenWebPageAction','URL-EXMultiRepresentations':{'cross-platform':url('https://example.invalid/inspection')}}},{'EXClassName':'HSSyntheticNBAAction','extensionName':'Example NBA','payload':{'opaqueBase64':'bm90LWV4ZWN1dGFibGU='}},{'EXClassName':'HSSyntheticHyperLogoAction','scriptText':'print [Inspection only]','scriptLanguage':'HyperLogo'},{'EXClassName':'HSOpenStackAction','URL-EXMultiRepresentations':{'cross-platform':url('missing-demo.stack')}},{'EXClassName':'HSPlaySoundAction','mediaUID':uid('MISSING-MEDIA')},{'EXClassName':'HSShowHideObjectAction','objectUID':uid('SHARED-BUTTON')},{'EXClassName':'HSOpenLocationAction','URL-EXMultiRepresentations':{'cross-platform':url('Contents/Resources/Shared_Background.png')}}]
group['actor']={'EXClassName':'HSActor','hyperActions-EXConformedCollection':[{'EXClassName':'HSSequencerAction','events-EXConformedCollection':[{'EXClassName':'HSActionEvent','_eventType':'HSClickActionEventType'}],'syntheticNestedActions':children}]}
for n,d in docs.items():
 if n.endswith('Card2.hscard/Shared.hsobject'):d['localNodeData']={'actor':{'EXClassName':'HSActor','hyperActions-EXConformedCollection':[{'EXClassName':'HSSyntheticSimpleScriptAction','scriptText':'Inspection-only source text; do not execute','scriptLanguage':'SimpleScript'}]}}
for n,d in docs.items():entries[n]=plistlib.dumps(d)
out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
 for n,v in entries.items():w.writestr(n,v)
data=out.getvalue();data=b'HS'+data[2:];(p/'Examples/Behavior_Inspection.hsa').write_bytes(data);(p/'source/Behavior_Inspection.hsa').write_bytes(data)
(p/'Examples/Behavior_Provenance.json').write_text(json.dumps({'author':'Michael Roberts','license':'MIT','nativeAuthored':False,'purpose':'Synthetic shared/nested action records, UUID/path/URI dependencies and script/NBA marker candidates; no actions execute','notice':'Synthetic class/field names demonstrate evidence handling; they do not establish native compatibility or complete language decoding'},indent=2))
print('Wrote behavior fixture',len(data))
