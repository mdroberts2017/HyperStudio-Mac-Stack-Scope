"""Validate the extracted release without network access. Michael Roberts, MIT."""
from pathlib import Path
import hashlib,html.parser,json,re,subprocess,tempfile,urllib.parse
root=Path(__file__).resolve().parent.parent
identity=json.loads((root/'Build_Identity.json').read_text());cfg=json.loads((root/'source/products.json').read_text())['mac'];plan=json.loads((root/'source/release-scope.json').read_text())
assert identity['phase']==cfg['phase']==plan['phase']=='HSM-P07-Final'
assert identity['version']==cfg['version']=='1.0' and identity['final']==cfg['final']==True
assert plan['version']=='1.0 Final' and plan['releaseCandidate'] is False and plan['finalRelease'] is True
assert all(g['status']=='passed' for g in plan['gates'] if g.get('requiredForCandidate',True))
assert not any(g['id']=='tablet' for g in plan['gates'])
assert plan['supportedDeviceClasses']==['Desktop']
name=cfg['stem']+'_'+cfg['version']+'_Final_'+cfg['phase']+'.html'
app=(root/name).read_text()
embedded=re.search(r'const HSReleasePlan=(.*?);\n',app)
assert embedded and json.loads(embedded[1])==plan
assert 'This build is validated with Node Canvas and DOM test doubles.' in app
assert 'Automated Chromium coverage is recorded' not in app
assert 'This development build is tested in headless Chromium 153' not in app
class CheckHTML(html.parser.HTMLParser):
 def __init__(self,path,offline=False):super().__init__();self.path=path;self.offline=offline;self.scripts=[];self.in_script=False
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='script':self.in_script=True
  if self.offline and (tag in ['script','img','iframe','source','video','audio'] or tag=='link'):
   v=a.get('src') or (a.get('href') if tag=='link' and a.get('rel')=='stylesheet' else None)
   assert not v or v.startswith('data:'),'External runtime dependency: '+str(v)
  href=a.get('href','')
  if href and not urllib.parse.urlsplit(href).scheme and not href.startswith('#'):
   target=urllib.parse.unquote(urllib.parse.urlsplit(href).path)
   assert (self.path.parent/target).exists(),'Broken local link in '+self.path.name+': '+target
 def handle_endtag(self,tag):
  if tag=='script':self.in_script=False
 def handle_data(self,data):
  if self.in_script:self.scripts.append(data)
checks=[]
for path in sorted(root.glob('*.html')):
 parser=CheckHTML(path,path.name==name);parser.feed(path.read_text())
 for script in parser.scripts:
  r=subprocess.run(['node','-e','new (require("vm").Script)(require("fs").readFileSync(0,"utf8"))'],input=script,text=True,capture_output=True)
  assert r.returncode==0,path.name+': '+r.stderr
 checks.append(path.name)
manifest=json.loads((root/'Integrity_Manifest.json').read_text());assert manifest['phase']==plan['phase']
for item in manifest['files']:
 path=root/item['path'];assert path.is_file(),item['path'];assert path.stat().st_size==item['bytes'],item['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],item['path']
with tempfile.TemporaryDirectory(prefix='hsm-build-') as out:
 subprocess.run(['python3',str(root/'source/build.py'),'--product','mac','--out',out],check=True,capture_output=True)
 for file in [name,'Build_Identity.json']:assert (Path(out)/'mac'/file).read_bytes()==(root/file).read_bytes(),'Rebuild differs: '+file
print(json.dumps({'phase':plan['phase'],'identity':True,'embeddedScope':True,'finalRelease':True,'tabletSupport':'Deferred beyond 1.0','requirementsWording':True,'offlineRuntimeDependencies':True,'topLevelHTMLLinksAndScripts':checks,'manifestFiles':len(manifest['files']),'exactRebuild':True,'browserCertification':False},indent=2))
