"""Original synthetic inspection fixture; Michael Roberts, 2026, MIT."""
import plistlib,zipfile,io,json
from PIL import Image, ImageDraw
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def uid(s):return {'EXClassName':'_HSCFUUID','stringValue':s}
def col(r,g,b):return {'cross-platform':{'redComponent':r,'greenComponent':g,'blueComponent':b,'alphaComponent':1}}
stack='Contents/Stack.hsstack/Stack.hsstack';docs={stack:{'EXClassName':'HSStack','localNodeData':{'UID':uid('STACK'),'name':'Shared-state inspection'},'cardSizeAsString':'{640, 480}','cardGroups-EXConformedCollection':[{'EXClassName':'HSCardGroup','groupData-EXConformedCollection':[{'EXClassName':'HSButtonObjectData','UID':uid('SHARED-BUTTON'),'nodeDataUID':uid('SHARED-DATA'),'name':'Shared control','title':'Shared control','titleVisible':1,'hidden':0,'enabled':1,'opacity':1,'backgroundStyle':'HSButtonObjectSystemBackgroundStyle'}],'nodeUnits':{'SIZE':{'EXClassName':'HSSizeNodeUnit','sizeAsString':'{170, 40}'},'GEO':{'EXClassName':'HSGeometryNodeUnit','affineTransformAsArray':[1,0,0,1,235,300]}}}]}}
for i,label in enumerate(['Shared control visible','Same shared data on another card','Local hidden override'],1):
 base=f'Contents/Stack.hsstack/Card{i}.hscard/'
 docs[base+'Card.hscard']={'EXClassName':'HSCard','localNodeData':{'UID':uid(f'CARD-{i}'),'name':label},'_title':label,'hyperOrderWeight':str(i),'backgroundGraphics':{'EXClassName':'HSColor','isSolid':0,'kindAsString':'Axial','startColor-EXMultiRepresentations':col(1,1,1),'endColor-EXMultiRepresentations':col(.2,.6,1)}}
 docs[base+'Shared.hsobject']={'EXClassName':'HSButtonObject','sharedNodeDataUID':uid('SHARED-DATA'),'hyperOrderWeight':'2','unitUIDs':{'Size Unit':'SIZE','Geometry Unit':'GEO'},'units':{}}
 if i==3:docs[base+'Shared.hsobject']['localNodeData']={'hidden':1}
 docs[base+'Text.hsobject']={'EXClassName':'HSSystemTextView','localNodeData':{'UID':uid(f'TEXT-{i}'),'name':'Explanation','hidden':0},'hyperText':{'attributedString':[{'string':label+'\n\nThis generated fixture demonstrates shared data, shared geometry, and saved hidden state. The stored gradient is a comparison candidate. Actions do not execute.','attributes':{'NSFont':{'familyName':'Arial','pointSize':20}}}]},'hyperOrderWeight':'1','units':{'TS':{'EXClassName':'HSSizeNodeUnit','sizeAsString':'{540, 210}'},'TG':{'EXClassName':'HSGeometryNodeUnit','affineTransformAsArray':[1,0,0,1,50,50]}}}
# Original artwork shared by two cards through a unit reference only.
bg=Image.new('RGBA',(640,480),'#fff7e5');draw=ImageDraw.Draw(bg);draw.rectangle((12,12,627,467),outline='#a66b22',width=3);draw.rectangle((22,22,617,457),outline='#d5b77b',width=1)
for y in range(390,451,12):draw.line((40,y,600,y),fill='#e1cfa8',width=1)
asset=io.BytesIO();bg.save(asset,format='PNG');asset=asset.getvalue()
docs[stack]['cardGroups-EXConformedCollection'][0]['nodeUnits']['BG']={'EXClassName':'HSEditableImageNodeUnit','mediaUID':uid('BACKGROUND-MEDIA')}
for i in [1,2]:docs[f'Contents/Stack.hsstack/Card{i}.hscard/Card.hscard']['unitUIDs']={'Editable Background':'BG'}
docs['Contents/Resources/MediaAccessor/Shared_Background.png.plist']={'EXClassName':'HSMediaWrapper','uid':uid('BACKGROUND-MEDIA'),'mediaName':'Original shared backdrop','mediaPath':'Shared_Background.png','mediaType':'image'}
b=io.BytesIO()
with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
 for n,d in docs.items():z.writestr(n,plistlib.dumps(d))
 z.writestr('Contents/Resources/Shared_Background.png',asset)
 z.writestr('Version.plist',plistlib.dumps({'CompatibilityVersionNumber':'5.0'}))
data=b.getvalue();data=b'HS'+data[2:];(root/'Examples/Shared_State_Inspection.hsa').write_bytes(data)
(root/'Examples/Shared_State_Provenance.json').write_text(json.dumps({'author':'Michael Roberts','license':'MIT','generated':True,'nativeAuthored':False,'purpose':'Three synthetic cards: shared data/control geometry; a shared background unit on Cards 1/2 without shared card data; hidden override and stored-gradient comparison on Card 3. Original generated backdrop. No vendor sample assets.'},indent=2))
print('Wrote',len(data),'bytes')
