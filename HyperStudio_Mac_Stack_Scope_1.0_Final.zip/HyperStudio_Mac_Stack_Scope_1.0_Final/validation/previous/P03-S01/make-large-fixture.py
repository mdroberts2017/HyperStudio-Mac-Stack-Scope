from pathlib import Path
import zipfile,io
Path('work').mkdir(exist_ok=True)
source=Path(__file__).resolve().parents[1]/'source/Mac_Inspection_Demo.hsa'
with zipfile.ZipFile(io.BytesIO(b"PK"+source.read_bytes()[2:])) as z,zipfile.ZipFile('work/Large_Media.hsa','w',zipfile.ZIP_DEFLATED) as out:
 for n in z.namelist():
  if not n.endswith('/') and n.endswith(('.hsstack','.hscard','.hsobject','.plist')):out.writestr(n,z.read(n))
 info=zipfile.ZipInfo('Contents/Resources/large-test.mov');info.compress_type=zipfile.ZIP_DEFLATED
 with out.open(info,'w') as f:
  for i in range(80):f.write(bytes(1024*1024))
