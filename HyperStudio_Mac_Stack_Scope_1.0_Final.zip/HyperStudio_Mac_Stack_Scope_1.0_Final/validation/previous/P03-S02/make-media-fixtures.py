from pathlib import Path
import wave,struct,io,zipfile,plistlib,json,shutil
root=Path('work/media');root.mkdir(parents=True,exist_ok=True)
shutil.copy2(Path(__file__).resolve().parents[1]/'Examples/Media/tiny.mov',root/'tiny.mov')
shutil.copy2(Path(__file__).resolve().parents[1]/'Examples/Media/movie-oracle.json',root/'movie-oracle.json')
with wave.open(str(root/'tone.wav'),'wb') as w:w.setparams((2,2,24000,0,'NONE','not compressed'));w.writeframes(bytes(24000*4))
(root/'events.mid').write_bytes(b'MThd'+struct.pack('>IHHH',6,1,1,480)+b'MTrk'+struct.pack('>I',4)+bytes.fromhex('00ff2f00'))
with wave.open(str(root/'large.wav'),'wb') as w:
 w.setparams((2,2,48000,0,'NONE','not compressed'))
 for i in range(80):w.writeframesraw(bytes(1048576))
base=Path(__file__).resolve().parents[1]/'Examples/Shared_State_Inspection.hsa';b=base.read_bytes();source=zipfile.ZipFile(io.BytesIO(b'PK'+b[2:]))
def build(dest,large=False):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_STORED) as z:
  for n in source.namelist():
   if not n.endswith('/'):z.writestr(n,source.read(n))
  for name in ['tone.wav','events.mid','tiny.mov']+(['large.wav'] if large else []):
   uid='MEDIA-'+name;wrapper={'EXClassName':'HSMediaWrapper','uid':{'EXClassName':'_HSCFUUID','stringValue':uid},'mediaName':name,'mediaPath':name,'mediaType':name.split('.')[-1]};z.writestr('Contents/Resources/MediaAccessor/'+name+'.plist',plistlib.dumps(wrapper));z.write(root/name,'Contents/Resources/'+name)
build(root/'Small_Media.hsa');build(root/'Large_Media.hsa',True)
# Same valid movie, with a large free atom before the final moov. Existing media data offsets stay unchanged.
b=(root/'tiny.mov').read_bytes();pos=0;atoms=[]
while pos<len(b):
 n=struct.unpack_from('>I',b,pos)[0];assert n>=8;atoms.append((b[pos+4:pos+8],b[pos:pos+n]));pos+=n
assert atoms[-1][0]==b'moov'
with open(root/'large-tail.mov','wb') as f:
 for typ,part in atoms[:-1]:f.write(part)
 f.write(struct.pack('>I4s',80*1048576+8,b'free'))
 for i in range(80):f.write(bytes(1048576))
 f.write(atoms[-1][1])
waveInfo={}
for n in ['tone.wav','large.wav']:
 with wave.open(str(root/n),'rb') as w:waveInfo[n]={'channels':w.getnchannels(),'bitsPerSample':w.getsampwidth()*8,'sampleRate':w.getframerate(),'frames':w.getnframes(),'durationSeconds':w.getnframes()/w.getframerate()}
(root/'wave-oracle.json').write_text(json.dumps(waveInfo,indent=2));print('Generated independent PCM/MIDI and Stored ZIP fixtures')
