/* Ross N. Williams, LZRW1-A, 25 June 1991. Original source declares public domain.
   Decompression excerpt, used only on verified valid corpus streams as an oracle.
   Source: https://mirrors.nic.funet.fi/pub/files/index/misc/compression/lzrw1-a.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char UBYTE;
typedef unsigned short UWORD;
typedef unsigned long ULONG;
#define LOCAL static
#define FLAG_BYTES 4
#define FLAG_COPY 1
#define fast_copy(src,dst,n) memcpy(dst,src,n)
LOCAL void compress_decompress(wrk_mem,p_src_first,src_len,p_dst_first,p_dst_len)
/* Input  : Specify input block using p_src_first and src_len.          */
/* Input  : Point p_dst_first to the start of the output zone.          */
/* Input  : Point p_dst_len to a ULONG to receive the output length.    */
/* Input  : Input block and output zone must not overlap. User knows    */
/* Input  : upperbound on output block length from earlier compression. */
/* Input  : In any case, maximum expansion possible is nine times.      */
/* Output : Length of output block written to *p_dst_len.               */
/* Output : Output block in Mem[p_dst_first..p_dst_first+*p_dst_len-1]. */
/* Output : Writes only  in Mem[p_dst_first..p_dst_first+*p_dst_len-1]. */
UBYTE *p_src_first, *p_dst_first; ULONG src_len, *p_dst_len; UBYTE *wrk_mem;
{register UBYTE *p_src=p_src_first+FLAG_BYTES, *p_dst=p_dst_first;
 UBYTE *p_src_post=p_src_first+src_len;
 UBYTE *p_src_max16=p_src_first+src_len-(16*2);
 register ULONG control=1;
 if (*p_src_first==FLAG_COPY)
   {fast_copy(p_src_first+FLAG_BYTES,p_dst_first,src_len-FLAG_BYTES);
    *p_dst_len=src_len-FLAG_BYTES; return;}
 while (p_src!=p_src_post)
   {register UWORD unroll;
    if (control==1) {control=0x10000|*p_src++; control|=(*p_src++)<<8;}
    unroll= p_src<=p_src_max16 ? 16 : 1;
    while (unroll--)
      {if (control&1)
         {register UWORD lenmt; register UBYTE *p;
          lenmt=*p_src++; p=p_dst-(((lenmt&0xF0)<<4)|*p_src++);
          *p_dst++=*p++; *p_dst++=*p++; *p_dst++=*p++;
          lenmt&=0xF; while (lenmt--) *p_dst++=*p++;}
       else
          *p_dst++=*p_src++;
       control>>=1;
      }
   }
 *p_dst_len=p_dst-p_dst_first;
}


int main(int argc,char **argv){if(argc!=3)return 2;FILE *f=fopen(argv[1],"rb");if(!f)return 3;fseek(f,0,SEEK_END);long size=ftell(f);rewind(f);if(size<4||size>1048576)return 4;unsigned char *src=malloc(size),*dst=calloc(size*9+1024,1);if(!src||!dst||fread(src,1,size,f)!=size)return 5;fclose(f);unsigned long n=0;compress_decompress(NULL,src,size,dst,&n);f=fopen(argv[2],"wb");if(!f||fwrite(dst,1,n,f)!=n)return 6;fclose(f);free(src);free(dst);return 0;}
