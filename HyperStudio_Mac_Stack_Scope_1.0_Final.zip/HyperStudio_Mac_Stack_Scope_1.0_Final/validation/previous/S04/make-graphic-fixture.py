"""Original graphic inspection fixture. Michael Roberts, MIT, 2026.
No native application or historical art/fonts used. Run from package root.
"""
from pathlib import Path
import struct,json,hashlib
base=bytearray(Path('Examples/Legacy_Mac_Inspection.stack').read_bytes());objects=[];checks=[]
def graphic(ident,w,h,bounds,flags):
 stride=(w+15)//16*16;raster=bytearray(stride*h)
 for y in range(h):
  for x in range(w):raster[y*stride+x]=1 if flags==16 else 2+(x//4+y//4)%2
 raw=bytearray(80);struct.pack_into('>HHhhhh',raw,0,16,ident,*bounds);struct.pack_into('>Hhhhh',raw,28,flags,0,0,h,w);struct.pack_into('>H',raw,54,8)
 if flags&16:
  for y in range(h):
   row=raster[y*stride:(y+1)*stride]
   # Constant 16px rows: literal + overlapping distance-one 15-byte match.
   stream=b'\x02\x00\x01\x0c\x01' if flags==16 else bytes(row)
   mode=0 if flags==16 else 1;n=4+len(stream);raw+=bytes([mode])+n.to_bytes(3,'big')+stream
 else:
  # Valid literal PackBits chunks across row boundaries.
  for p in range(0,len(raster),128):part=raster[p:p+128];raw+=bytes([len(part)-1])+part
 mask=None
 if flags&2:
  ms=(w+31)//32*4;mask=bytearray(ms*h)
  for y in range(h):
   for x in range(w):
    if 2<=x<w-2 and 2<=y<h-2:mask[y*ms+x//8]|=128>>(x%8)
  struct.pack_into('>I',raw,60,24+len(mask));raw+=struct.pack('>HH',w,h)+bytes(20)+mask
 struct.pack_into('>I',raw,12,len(raw));objects.append(raw);checks.append({'id':ident,'width':w,'height':h,'rasterSHA256':hashlib.sha256(raster).hexdigest(),'maskSHA256':hashlib.sha256(mask).hexdigest() if mask is not None else None,'bounds':dict(zip(['top','left','bottom','right'],bounds))})
graphic(20,24,24,(144,236,192,284),2)
graphic(21,17,19,(142,285,180,319),18)
graphic(22,16,16,(182,-8,198,8),16)
data=base[:-4]+b''.join(objects)+base[-4:];struct.pack_into('>I',data,130,len(data)-128)
p=Path('Examples/Legacy_Graphics_Inspection.stack');p.write_bytes(data)
Path('Examples/Graphics_Fixture_Provenance.json').write_text(json.dumps({'author':'Michael Roberts','license':'MIT','created':'2026-10-23','nativeApplicationValidation':False,'sha256':hashlib.sha256(data).hexdigest(),'purpose':'Whole-raster PackBits, copied and compressed LZ rows, masks, scaling, clipping and saved field bounds','graphics':checks},indent=2));print(p,len(data))
