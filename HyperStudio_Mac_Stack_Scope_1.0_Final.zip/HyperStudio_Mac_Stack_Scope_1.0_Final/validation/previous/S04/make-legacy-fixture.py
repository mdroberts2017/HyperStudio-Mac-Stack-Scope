"""Original synthetic legacy Mac inspection fixture. Michael Roberts, MIT, 2026.
Not produced or validated by native HyperStudio. No historical fonts or art embedded.
"""
from pathlib import Path
import struct,hashlib,json
out=Path('work/s02/fixtures');out.mkdir(parents=True,exist_ok=True)
u=lambda n:struct.pack('>H',n)
W,H=320,200
raster=bytearray(W*H)
def rect(x,y,w,h,color):
 for yy in range(y,y+h):raster[yy*W+x:yy*W+x+w]=bytes([color])*w
rect(0,0,W,30,1);rect(12,42,296,96,3);rect(14,44,292,92,0);rect(20,156,200,28,1)
colors=[(255,255,255),(27,63,116),(40,110,173),(150,170,195)]
palette=bytearray()
for i in range(256):
 rgb=colors[i] if i<len(colors) else (i,i,i);palette+=struct.pack('>HHHH',i,*(v*257 for v in rgb))
paint=bytearray(32);struct.pack_into('>HHI',paint,16,0,0x0808,0);struct.pack_into('>H',paint,30,255);paint+=palette+bytes(16)+b'\1\0\0\0'+raster;struct.pack_into('>HHI',paint,0,8,2,0);struct.pack_into('>I',paint,12,len(paint))
def field(ident,bounds,text,styles):
 data=text.encode('mac_roman');suffix=u(len(styles))
 for start,size,font,face,height,ascent,rgb in styles:suffix+=struct.pack('>IHHHBBHHHH',start,height,ascent,font,face,0,size,*(v*257 for v in rgb))
 segment=bytearray(16);struct.pack_into('>HHII',segment,0,99,1,0,len(data));struct.pack_into('>I',segment,12,16+len(data)+len(suffix)+(len(data)%2));segment+=data+suffix+bytes(len(data)%2)
 fixed=bytearray(128);struct.pack_into('>HHhhhhI',fixed,0,96,ident,*bounds,128+len(segment));return fixed+segment
heading=field(3,(3,14,29,310),'Legacy Macintosh inspection',[(0,18,20,1,21,17,(255,255,255))])
content=field(4,(48,20,129,300),'Saved color and TextEdit metrics.\rCafé — styled runs stay inside this field.\r'+('Long text remains clipped. '*8),[(0,14,21,0,16,13,(27,63,116)),(33,14,20,2,16,13,(40,110,173))])
button=bytearray(136);label=b'Optional recovered label';struct.pack_into('>HHhhhhI',button,0,48,5,156,20,184,220,136);button[28]=len(label);button[29:29+len(label)]=label
header=bytearray(128);struct.pack_into('>H',header,16,8);struct.pack_into('>HH',header,56,W,H);card=bytearray(96);struct.pack_into('>HIH',card,0,1,96+len(paint)+len(heading)+len(content)+len(button)+4,1)
data=header+card+paint+heading+content+button+struct.pack('>I',0xface);p=out/'Legacy_Mac_Inspection.stack';p.write_bytes(data)
(out/'Fixture_Provenance.json').write_text(json.dumps({'kind':'original synthetic inspection fixture','author':'Michael Roberts','nativeApplicationValidation':False,'width':W,'height':H,'sha256':hashlib.sha256(data).hexdigest(),'paintRGBAExpected':'Saved palette/raster only; editable text is separate','notes':'Literal-copy LZRW body, TextEdit scrap styles, clipped fields, optional button overlay.'},indent=2));print(p,len(data))
