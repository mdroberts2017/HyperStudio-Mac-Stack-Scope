HyperStudio Mac Stack Scope 0.8.4 Dev2 / HSM-P05-S02
Michael Roberts — October 25, 2026 — MIT
Extract and open Start_Here.html.
Hardens image-cache ownership, preview cancellation and temporary canvas cleanup.
Adds browser review worksheet with manual JSON report export.
Accepted button sizing/label fitting retained. No saved actions execute.
Node/Canvas and DOM-double regressions pass; browser/native acceptance remains open.
Next: HSM-P06-S01 — scope freeze and RC readiness review.
