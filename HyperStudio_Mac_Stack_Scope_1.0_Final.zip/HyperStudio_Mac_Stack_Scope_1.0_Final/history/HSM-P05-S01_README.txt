HyperStudio Mac Stack Scope 0.8.4 Dev1 / HSM-P05-S01
Michael Roberts — October 24, 2026 — MIT
Extract and open Start_Here.html.
Corrects active system-button appearance sizing and adds measured bounded label layout, plus toolbar wrapping.
Home card 28 review recommended. Separate text-field/native font layout remains approximate.
Source, fixtures, tests and evidence included. No saved behavior executes.
Real-browser/native acceptance remains open.
Next: HSM-P05-S02.
