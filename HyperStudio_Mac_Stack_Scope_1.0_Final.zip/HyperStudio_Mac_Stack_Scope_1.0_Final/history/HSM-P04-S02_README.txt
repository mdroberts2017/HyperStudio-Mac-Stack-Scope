HyperStudio Mac Stack Scope 0.8.3 Dev2 / HSM-P04-S02
Michael Roberts — October 24, 2026 — MIT
Extract and open Start_Here.html.
Opening screen: Load behavior inspection example.
Adds paged actions/dependencies/markers/source definitions, exact shared/local provenance and graph export.
Saved actions and external references are never executed/opened/fetched.
Home 582-record ownership and 28-card Preview regressions pass under Node/Canvas.
Real-browser/native acceptance and complete NBA/language decoding remain open.
Adds graph integrity checks, review groups with source-location counts, owner navigation and review JSON export.
Next: HSM-P05-S01, resource and browser hardening.
