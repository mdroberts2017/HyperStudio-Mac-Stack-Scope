HyperStudio Mac Stack Scope 0.8.5 RC1 / HSM-P07-RC01
Michael Roberts — October 25, 2026 — MIT
Release Candidate 1. Extract and open Start_Here.html.
Accepted Dev3 inspection/rendering implementation unchanged.
User-reported Safari, Firefox, Chrome and Microsoft Edge success recorded.
Specific versions/OS/device details unspecified; tablet validation unverified.
Known visual approximations and inspection-only scope retained.
Test the explicitly named RC1; next is RC acceptance/fixes, then Final promotion.
