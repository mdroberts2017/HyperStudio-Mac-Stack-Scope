HyperStudio Mac Stack Scope 0.8.5 Dev1 / HSM-P06-S01
Michael Roberts — October 25, 2026 — MIT
Extract and open Start_Here.html.
Scope freeze review; not a Release Candidate.
About / Help → Release scope & readiness shows scope/gates and exports JSON.
Accepted P05-S02 implementation modules unchanged.
See Release_Scope.html, Browser_Acceptance.html and Test_Guide.html.
Direct browser/device and native-reference review remain open.
Next: HSM-P06-S02.
