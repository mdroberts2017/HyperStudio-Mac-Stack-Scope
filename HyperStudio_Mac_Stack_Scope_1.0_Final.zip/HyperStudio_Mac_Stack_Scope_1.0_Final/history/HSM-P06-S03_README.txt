HyperStudio Mac Stack Scope 0.8.5 Dev3 / HSM-P06-S03
Michael Roberts — October 25, 2026 — MIT
Extract and open Start_Here.html.
About / Help → Release scope & readiness → Run environment checks.
Capability probes are included in readiness JSON; they do not certify browser/native fidelity.
Inspection/rendering baseline unchanged. Not a Release Candidate.
RC promotion now awaits browser/device review evidence and visual acceptance; resolve any blockers before promotion.
