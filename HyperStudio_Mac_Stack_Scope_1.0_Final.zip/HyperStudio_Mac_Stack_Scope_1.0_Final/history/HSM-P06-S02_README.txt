HyperStudio Mac Stack Scope 0.8.5 Dev2 / HSM-P06-S02
Michael Roberts — October 25, 2026 — MIT
Extract and open Start_Here.html.
Scope accepted; manual acceptance-evidence intake added. Not a Release Candidate.
About / Help → Release scope & readiness imports Browser_Acceptance.html JSON reports.
Browser/device and visual review remain open initially; no direct browser certification added.
Reports remain in this app session; export readiness evidence before reload.
Next: HSM-P06-S03.
