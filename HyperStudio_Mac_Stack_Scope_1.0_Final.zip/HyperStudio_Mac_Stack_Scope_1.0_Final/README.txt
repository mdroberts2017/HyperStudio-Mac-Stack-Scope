HyperStudio Mac Stack Scope 1.0 Final / HSM-P07-Final
Michael Roberts — October 25, 2026 — MIT
FINAL RELEASE. Promoted from accepted 0.8.5 RC1.
Extract and open Start_Here.html.
Desktop browsers; user-reported Safari, Firefox, Chrome and Microsoft Edge success retained.
Tablet support deferred to a possible future version, outside 1.0 support and acceptance scope.
Inspection/rendering/media baseline unchanged. Known visual approximations remain.
No imported actions, scripts, NBA code or media execute.
Complete source, examples, documentation, validation, notices and hashes included.
