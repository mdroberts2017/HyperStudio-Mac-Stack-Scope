"""Independent corpus checks. Usage: python3 research/verify-legacy-graphics.py CORPUS_ROOT OUTPUT_DIR
Requires Python 3 and gcc. Original corpus is not redistributed. Michael Roberts, MIT, 2026.
"""
from pathlib import Path
import sys,json,hashlib,struct,subprocess,collections
root=Path(sys.argv[1]);output=Path(sys.argv[2]);output.mkdir(parents=True,exist_ok=True)
base=Path(__file__).resolve().parent.parent
manifest=json.loads((base/'validation/Legacy_Corpus_Manifest.json').read_text())
def lz(data):
 if data[0]==1:return bytes(data[4:])
 out=bytearray();p=4
 while p<len(data):
  flags=int.from_bytes(data[p:p+2],'little');p+=2
  for bit in range(16):
   if p==len(data):break
   if flags&(1<<bit):
    a,b=data[p:p+2];p+=2;distance=((a&240)<<4)+b
    assert 0<distance<=len(out)
    for j in range((a&15)+3):out.append(out[-distance])
   else:out.append(data[p]);p+=1
 assert p==len(data)
 return bytes(out)
def pack(data,length):
 p=0;out=bytearray()
 while len(out)<length:
  c=data[p];p+=1
  if c<128:out.extend(data[p:p+c+1]);p+=c+1
  elif c>128:out.extend(data[p:p+1]*(257-c));p+=1
  assert len(out)<=length
 return bytes(out),p
results=[];streams=[];stream_outputs=[];counts=collections.Counter()
for entry in manifest:
 b=(root/entry['name']).read_bytes();assert hashlib.sha256(b).hexdigest()==entry['sha256'];cards=[];p=128
 while p+100<=len(b):
  size=int.from_bytes(b[p+2:p+6],'big')
  if size<100 or p+size>len(b):break
  c={'id':int.from_bytes(b[p:p+2],'big'),'ref':int.from_bytes(b[p+8:p+10],'big'),'objects':[]};q=p+96
  while q<p+size-4:
   n=int.from_bytes(b[q+12:q+16],'big');assert n>=16;c['objects'].append((int.from_bytes(b[q:q+2],'big'),q,b[q:q+n]));q+=n
  cards.append(c);p+=size
 for card in cards:
  owner=card;seen=set()
  while not any(t==8 for t,_,_ in owner['objects']):
   assert owner['id'] not in seen;seen.add(owner['id']);owner=next(c for c in cards if c['id']==owner['ref'])
  paint=next(raw for t,_,raw in owner['objects'] if t==8)
  palette=[[(int.from_bytes(paint[34+i*8+k:36+i*8+k],'big')+128)//257 for k in (0,2,4)] for i in range(256)]
  for kind,offset,raw in card['objects']:
   if kind!=16:continue
   flags=int.from_bytes(raw[28:30],'big');top,left,bottom,right=struct.unpack_from('>hhhh',raw,30);assert top==left==0;w,h=right,bottom;stride=(w+15)//16*16;p=80
   if flags&16:
    rows=[]
    for y in range(h):
     n=int.from_bytes(raw[p+1:p+4],'big');stream=raw[p:p+1]+b'\0'*3+raw[p+4:p+n];data=lz(stream);assert len(data)==stride;rows.append(data);streams.append(stream);stream_outputs.append(data);p+=n
    raster=b''.join(rows);counts['lzGraphics']+=1
   else:raster,n=pack(raw[p:],stride*h);p+=n;counts['packBitsGraphics']+=1
   mask=None
   if flags&2:
    n=int.from_bytes(raw[60:64],'big');maskstride=(w+31)//32*4;assert n==24+maskstride*h;assert raw[p:p+4]==struct.pack('>HH',w,h);assert raw[p+4:p+24]==b'\0'*20;mask=raw[p+24:p+n];p+=n;counts['maskedGraphics']+=1
   else:assert int.from_bytes(raw[60:64],'big')==0
   assert len(raw)-p in (0,1)
   rgba=bytearray()
   for y in range(h):
    for x in range(w):rgba.extend(palette[raster[y*stride+x]]+[255 if mask is None or mask[y*maskstride+x//8]&(128>>(x%8)) else 0])
   results.append({'name':entry['name'],'card':card['id'],'object':int.from_bytes(raw[2:4],'big'),'offset':offset,'width':w,'height':h,'rasterSHA256':hashlib.sha256(raster).hexdigest(),'rgbaSHA256':hashlib.sha256(rgba).hexdigest(),'maskSHA256':hashlib.sha256(mask).hexdigest() if mask is not None else None})
# The historical decompressor is an unbounded oracle: verified valid streams only.
code=(base/'validation/lzrw1a-reference.c').read_text().split('int main(')[0]
code+='''int main(int argc,char **argv){FILE *f=fopen(argv[1],"rb"),*g=fopen(argv[2],"wb");unsigned int size;unsigned char src[65536],dst[65536];unsigned long n;while(fread(&size,4,1,f)==1){if(size>65536)return 2;if(fread(src,1,size,f)!=size)return 3;compress_decompress(NULL,src,size,dst,&n);if(n>65536)return 4;size=n;fwrite(&size,4,1,g);fwrite(dst,1,n,g);}fclose(f);fclose(g);return 0;}'''
(output/'graphic-lz-oracle.c').write_text(code)
subprocess.run(['gcc','-O2','-std=gnu89',str(output/'graphic-lz-oracle.c'),'-o',str(output/'graphic-lz-oracle')],check=True)
(output/'lz-input.bin').write_bytes(b''.join(struct.pack('=I',len(s))+s for s in streams))
subprocess.run([str((output/'graphic-lz-oracle').resolve()),str(output/'lz-input.bin'),str(output/'lz-output.bin')],check=True)
b=(output/'lz-output.bin').read_bytes();p=0
for expected in stream_outputs:
 n=struct.unpack_from('=I',b,p)[0];p+=4;assert b[p:p+n]==expected;p+=n
assert p==len(b)
counts['lzRowsCheckedAgainstOriginalC']=len(streams);counts['graphics']=len(results)
(output/'graphics-oracle.json').write_text(json.dumps({'counts':dict(counts),'graphics':results,'nativePlaybackCompared':False},indent=2));print(dict(counts))
