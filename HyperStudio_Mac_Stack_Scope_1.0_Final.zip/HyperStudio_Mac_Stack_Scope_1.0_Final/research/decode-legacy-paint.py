from pathlib import Path
import json,struct,collections,hashlib
from PIL import Image
root=Path('work/legacy-corpus');records=json.load(open('work/s02/legacy-analysis.json'));outdir=Path('work/s02/decoded');outdir.mkdir(exist_ok=True);results=[]
def unpack(b,expected):
 if len(b)<4:raise Exception('no flag')
 flag=b[:4];p=4;out=bytearray()
 if flag[0]==1:
  out.extend(b[4:4+expected]);p=4+expected
 elif flag==b'\0'*4:
  while len(out)<expected:
   if p+2>len(b):raise Exception('short control')
   ctl=int.from_bytes(b[p:p+2],'little');p+=2
   for bit in range(16):
    if len(out)>=expected:break
    if ctl>>bit&1:
     if p+2>len(b):raise Exception('short token')
     a,c=b[p:p+2];p+=2;distance=((a&240)<<4)|c;n=(a&15)+3
     if distance<1 or distance>len(out) or len(out)+n>expected:raise Exception(('bad copy',p,distance,n,len(out),expected))
     for _ in range(n):out.append(out[-distance])
    else:
     if p>=len(b):raise Exception('short literal')
     out.append(b[p]);p+=1
 else:raise Exception(('flag',flag.hex()))
 if len(out)!=expected:raise Exception('output length')
 return out,p
for r in records:
 b=(root/r['name']).read_bytes();w,h=struct.unpack_from('>HH',b,56);stride=(w+3)&~3
 for card in r['cards']:
  for o in card['objects']:
   if o['type']!=8:continue
   raw=b[o['offset']:o['offset']+o['size']];lead=int.from_bytes(raw[2084:2088],'big');tail=int.from_bytes(raw[2092:2096],'big');target=stride*h-lead-tail
   row={'name':r['name'],'card':card['id'],'width':w,'height':h,'stride':stride,'lead':lead,'tail':tail,'middle':target,'size':o['size']}
   try:
    middle,used=unpack(raw[2096:],target) if target else (b'',0);data=bytearray((raw[2080:2084]*((lead+3)//4))[:lead])+middle+bytearray((raw[2088:2092]*((tail+3)//4))[:tail]);assert len(data)==stride*h
    palette=[]
    for i in range(256):idx,rr,g,bb=struct.unpack_from('>HHHH',raw,32+8*i);assert idx==i;palette.extend([round(rr/257),round(g/257),round(bb/257)])
    im=Image.frombytes('P',(stride,h),bytes(data));im.putpalette(palette);im=im.crop((0,0,w,h));fn=str(len(results)).zfill(3)+'_'+str(card['id'])+'.png';im.save(outdir/fn);row.update(decoded=True,used=used,trailing=len(raw)-2096-used,trailingHex=raw[2096+used:].hex()[:128],image=fn,rasterSHA256=hashlib.sha256(data).hexdigest())
   except Exception as e:row.update(decoded=False,error=str(e))
   results.append(row)
json.dump(results,open('work/s02/paint-oracle.json','w'),indent=2);print('decoded',sum(x['decoded'] for x in results),'/',len(results));print([r for r in results if not r['decoded']][:5]);print('tails',collections.Counter((r.get('trailing'),r.get('trailingHex')) for r in results))
