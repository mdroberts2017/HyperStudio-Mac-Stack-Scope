from pathlib import Path
import json,subprocess,hashlib
code=Path('work/s02/lzrw1-a.c').read_text();function=code[code.index('LOCAL void compress_decompress('):code.index('/*                             End of LZRNW1-A.C')];function=function[:function.rfind('/******************************************************************************/')]
prefix='''/* Ross N. Williams, LZRW1-A, 25 June 1991. Original source declares public domain.
   Decompression excerpt, used only on verified valid corpus streams as an oracle.
   Source: https://mirrors.nic.funet.fi/pub/files/index/misc/compression/lzrw1-a.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char UBYTE;
typedef unsigned short UWORD;
typedef unsigned long ULONG;
#define LOCAL static
#define FLAG_BYTES 4
#define FLAG_COPY 1
#define fast_copy(src,dst,n) memcpy(dst,src,n)
'''
suffix='''
int main(int argc,char **argv){if(argc!=3)return 2;FILE *f=fopen(argv[1],"rb");if(!f)return 3;fseek(f,0,SEEK_END);long size=ftell(f);rewind(f);if(size<4||size>1048576)return 4;unsigned char *src=malloc(size),*dst=calloc(size*9+1024,1);if(!src||!dst||fread(src,1,size,f)!=size)return 5;fclose(f);unsigned long n=0;compress_decompress(NULL,src,size,dst,&n);f=fopen(argv[2],"wb");if(!f||fwrite(dst,1,n,f)!=n)return 6;fclose(f);free(src);free(dst);return 0;}
'''
Path('work/s02/lzrw1a-reference.c').write_text(prefix+function+suffix)
subprocess.run(['gcc','-O2','-std=gnu89','work/s02/lzrw1a-reference.c','-o','work/s02/lzrw1a-reference'],check=True)
exec(Path('work/decode-legacy-paint.py').read_text().split('for r in records:')[0])
results=[]
for r in records:
 b=(root/r['name']).read_bytes();w,h=__import__('struct').unpack_from('>HH',b,56)
 for card in r['cards']:
  for o in card['objects']:
   if o['type']!=8:continue
   raw=b[o['offset']:o['offset']+o['size']];n=((w+3)&~3)*h-int.from_bytes(raw[2084:2088],'big')-int.from_bytes(raw[2092:2096],'big')
   if not n:continue
   decoded,used=unpack(raw[2096:],n);Path('work/s02/oracle-input.bin').write_bytes(raw[2096:2096+used]);subprocess.run(['work/s02/lzrw1a-reference','work/s02/oracle-input.bin','work/s02/oracle-output.bin'],check=True);actual=Path('work/s02/oracle-output.bin').read_bytes();assert actual==decoded
   results.append({'file':r['name'],'card':card['id'],'bytes':n,'sha256':hashlib.sha256(actual).hexdigest()})
json.dump({'oracle':'Ross Williams original LZRW1-A decompression excerpt, public domain','sourceURL':'https://mirrors.nic.funet.fi/pub/files/index/misc/compression/lzrw1-a.c','sourceSHA256':hashlib.sha256(Path('work/s02/lzrw1-a.c').read_bytes()).hexdigest(),'matchedNonemptyStreams':len(results),'emptyRasterBodies':2,'results':results,'nativeApplicationPlayback':False},open('work/s02/c-oracle-validation.json','w'),indent=2);print('Original C matches',len(results),'middle rasters')
