from pathlib import Path
import struct,json,hashlib,collections
manifest=json.load(open('work/early-p04/validation/legacy_corpus_manifest.json'));root=Path('work/legacy-corpus');out=Path('work/s02');out.mkdir(exist_ok=True)
records=[]
for f in manifest:
 p=root/f['name'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'];v=lambda at,n=2: int.from_bytes(b[at:at+n],'big');cards=[];offset=128
 while offset+100<=len(b):
  size=v(offset+2,4)
  if size<100 or offset+size>len(b):break
  card={'offset':offset,'size':size,'id':v(offset),'objects':[]};q=offset+96
  while q<offset+size-4:
   n=v(q+12,4);assert n>=16
   o={'offset':q,'type':v(q),'size':n,'hex':b[q:q+min(192,n)].hex(' ')};card['objects'].append(o);q+=n
  cards.append(card);offset+=size
 records.append({'name':f['name'],'bytes':len(b),'header':b[:128].hex(' '),'cards':cards})
json.dump(records,open(out/'legacy-analysis.json','w'),indent=2)
counts=collections.Counter();types=collections.defaultdict(list)
for r in records:
 for c in r['cards']:
  for o in c['objects']:counts[o['type']]+=1;types[o['type']].append((r['name'],c['id'],o))
print('types',counts)
for t in [8,16,96]:
 print('\nTYPE',t)
 for name,id,o in types[t][:5]:print(name,id,'size',o['size'],o['hex'][:540])
